This font folder exists for backwards compatibility. 
The fonts that currently in use reside in /css/fonts
folder.